﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nr1;
            double nr2;
            double nr3;

            Console.Write("Digite aqui o 1º número a ser verificado: ");
            nr1 = double.Parse(Console.ReadLine());
            Console.Write("Digite aqui o 2º número a ser verificado: ");
            nr2 = double.Parse(Console.ReadLine());
            Console.Write("Digite aqui o 2º número a ser verificado: ");
            nr3 = double.Parse(Console.ReadLine());

            if (((nr1 + nr2) > nr3) && ((nr2 + nr3) > nr1) && ((nr1 + nr3) > nr2))
            {
                if ( (nr1 != nr2) && (nr1 != nr3) && (nr1 != nr2))
                {
                    Console.WriteLine("Os números formam um triângulo Escaleno!");
                }
                else
                {
                    if( (nr1 == nr2) && (nr1 == nr3))
                    {
                        Console.WriteLine("Os números formam um  triângulo equilátero!");
                    }
                    else
                    {
                        Console.WriteLine("Os números formam um  triângulo isóceles!");
                    }
                }
            }
            else
            {
                Console.WriteLine("Os números não caracterizam um triângulo!");
            }
        }
    }
}
