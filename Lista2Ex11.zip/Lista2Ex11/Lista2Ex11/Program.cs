﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double p1;
            double p2;

            Console.Write("Insira a nota da P1: ");
            p1 = double.Parse(Console.ReadLine());

            p2 = (15 - p1) / 2;

            Console.WriteLine("O aluno deve tirar {0} na P2 para ser APROVADO!", p2);

        }
    }
}
