﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double p1;
            double p2;
            double media;

            Console.Write("Insira a nota da P1: ");
            p1 = double.Parse(Console.ReadLine());
            Console.Write("Insira a nota da P2: ");
            p2 = double.Parse(Console.ReadLine());

            media = (p1 + p2 + p2) / 3;

            if (media >= 5)
            {
                Console.WriteLine("O aluno está APROVADO!");
            }
            else
            {
                Console.WriteLine("O aluno está REPROVADO!");
            }
        }
    }
}
