﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nr1;
            double nr2;
            double nr3;

            double p1;
            double p2;
            double p3;

            Console.Write("Digite aqui o 1º número a ser verificado: ");
            nr1 = double.Parse(Console.ReadLine());
            Console.Write("Digite aqui o 2º número a ser verificado: ");
            nr2 = double.Parse(Console.ReadLine());
            Console.Write("Digite aqui o 2º número a ser verificado: ");
            nr3 = double.Parse(Console.ReadLine());

            p1 = Math.Pow(nr2, 2) + Math.Pow(nr3, 2); // possibilidade 1 -> "hip = nr1" && "cat = nr2 && nr3"
            p2 = Math.Pow(nr1, 2) + Math.Pow(nr3, 2); // possibilidade 2 -> "hip = nr2" && "cat = nr1 && nr3"
            p3 = Math.Pow(nr1, 2) + Math.Pow(nr2, 2); // possibilidade 3 -> "hip = nr3" && "cat = nr1 && nr2"

            if (Math.Pow(nr1, 2) == p1)
            {
                Console.WriteLine("Os valores inseridos( '{0}', '{1}' e '{2}' ) caracterizam triângulo retângulo!", nr1, nr2, nr3);
            }
            else
            {
                if (Math.Pow(nr2, 2) == p2)
                {
                    Console.WriteLine("Os valores inseridos( '{0}', '{1}' e '{2}' ) caracterizam triângulo retângulo!", nr1, nr2, nr3);
                }
                else
                {
                    if (Math.Pow(nr3, 2) == p3)
                    {
                        Console.WriteLine("Os valores inseridos( '{0}', '{1}' e '{2}' ) caracterizam triângulo retângulo!", nr1, nr2, nr3);
                    }
                    else
                    {
                        Console.WriteLine("Os valores inseridos( '{0}', '{1}' e '{2}' ) NÃO caracterizam triângulo retângulo!", nr1, nr2, nr3);
                    }
                }
            }                        
        }
    }
}
