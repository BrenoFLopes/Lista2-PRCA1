﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double peso;
            double altura;
            double relacao;

            Console.Write("Digite aqui o peso da pessoa: ");
            peso = double.Parse(Console.ReadLine());
            Console.Write("Digite aqui a altura da pessoa: ");
            altura = double.Parse(Console.ReadLine());

            relacao = peso / Math.Pow(altura, 2);

            if (relacao < 20)
            {
                Console.WriteLine("A pessoa está abaixo do peso!");
            }
            else
            {
                if (relacao >= 25)
                {
                    Console.WriteLine("A pessoa está acima do peso!");
                }
                else
                {
                    Console.WriteLine("A pessoa está no peso ideal!");
                }
            }
        }
    }
}


