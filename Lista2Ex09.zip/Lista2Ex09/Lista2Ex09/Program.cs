﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double peso;
            string sexo;
            double altura;
            double relacao;

            Console.Write("Digite aqui o peso da pessoa: ");
            peso = double.Parse(Console.ReadLine());
            Console.Write("Digite aqui a altura da pessoa: ");
            altura = double.Parse(Console.ReadLine());
            Console.Write("Digite '0' para o sexo 'Feminino' ou '1' para o sexo 'Masculino'");
            sexo = Console.ReadLine();


            relacao = peso / Math.Pow(altura, 2);

            if (sexo == "0") // Verificação para mulher
            {
                if (relacao < 19)
                {
                    Console.WriteLine("A mulher está abaixo do peso!");
                }
                else
                {
                    if (relacao >= 24)
                    {
                        Console.WriteLine("A mulher está acima do peso!");
                    }
                    else
                    {
                        Console.WriteLine("A mulher está no peso ideal!");
                    }
                }
            }

            else // Verificação para homem
            {
                if (relacao < 20)
                {
                    Console.WriteLine("O homem está abaixo do peso!");
                }
                else
                {
                    if (relacao >= 25)
                    {
                        Console.WriteLine("O homem está acima do peso!");
                    }
                    else
                    {
                        Console.WriteLine("O homem está no peso ideal!");
                    }
                }
            }

        }
    }
}
