﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nr1;
            double nr2;
            double nr3;

            Console.Write("Digite aqui o 1º número: ");
            nr1 = double.Parse(Console.ReadLine());
            Console.Write("Digite aqui o 2º número: ");
            nr2 = double.Parse(Console.ReadLine());
            Console.Write("Digite aqui o 3º número: ");
            nr3 = double.Parse(Console.ReadLine());

            if ((nr1 == nr2) && (nr2 == nr3))
            {
                Console.WriteLine("Os números inseridos são idênticos: {0}", nr1); // nr1 = nr2 = nr3
            }
            else
            {
                if( (nr1 > nr2) && (nr1 > nr3)) 
                {
                    Console.WriteLine("O 1º número inserido é o maior: {0}", nr1); //1
                }
                if ((nr1 == nr2) && (nr1 > nr3))
                {
                    Console.WriteLine("O 1º e o 2º números inseridos são os maiores: {0}", nr1); // 1 e 2
                }
                if ((nr1 == nr3) && (nr1 > nr2))
                {
                    Console.WriteLine("O 1º e o 3º números inseridos são os maiores: {0}", nr1); // 1 e 3
                }
                // nr1 > all
                if ((nr2 > nr1) && (nr2 > nr3)) 
                {
                    Console.WriteLine("O 2º número inserido é o maior: {0}", nr2); // 2
                }
                if ((nr2 == nr3) && (nr2 > nr1))
                {
                    Console.WriteLine("O 2º e o 3º números inseridos são os maiores: {0}", nr3); // 2 e 3
                }
                // nr2 > all
                if ((nr3 > nr2) && (nr3 > nr1))
                {
                    Console.WriteLine("O 3º número inserido é o maior: {0}", nr3); // 3
                }
                // nr3 > all
            }
        }
    }
}
