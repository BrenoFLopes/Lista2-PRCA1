﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nr1;
            double nr2;

            Console.Write("Digite aqui o 1º número: ");
            nr1 = double.Parse(Console.ReadLine());
            Console.Write("Digite aqui o 2º número: ");
            nr2 = double.Parse(Console.ReadLine());

            if (nr1 > nr2)
            {
                Console.WriteLine("O maior número é o 1º inserido: {0}", nr1);
            }
            else
            {
                Console.WriteLine("O maior número é o 2º inserido: {0}", nr2);
            }
        }
    }
}
