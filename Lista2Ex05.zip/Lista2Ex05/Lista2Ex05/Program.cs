﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2Ex05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double base1;
            double largura;
            double area;

            Console.Write("Digite aqui o tamanho da base do terreno: ");
            base1 = double.Parse(Console.ReadLine());
            Console.Write("Digite aqui o tamanho da largura do terreno: ");
            largura = double.Parse(Console.ReadLine());

            area = base1 * largura;

            if (area > 100)
            {
                Console.WriteLine("Terreno Grande!");
            }
            else
            {
                Console.WriteLine("Terreno Pequeno!");
            }
        }
    }
}
